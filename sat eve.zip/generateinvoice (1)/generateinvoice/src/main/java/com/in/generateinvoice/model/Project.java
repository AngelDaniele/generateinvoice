package com.in.generateinvoice.model;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name="Project")
public class Project {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="projectTableId")
    private int projectTableId;

    @Column(name="projectId")
    private String projectId;

    @Column(name="projectName")
    private String projectName;
    @Column(name="startDate")
    private LocalDate startDate;
    @Column(name="endDate")
    private LocalDate endDate;

    @ManyToOne
    @JoinColumn(name = "clientTableId")
    private Client client;
    @Column(name="budget")
    private int budget;

    public Project() {

    }

    public Project(String projectId) {
    }


    public int getProjectTableId() {
        return projectTableId;
    }

    public void setProjectTableId(int projectTableId) {
        this.projectTableId = projectTableId;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }


    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public int getBudget() {
        return budget;
    }

    public void setBudget(int budget) {
        this.budget = budget;
    }



}
