package com.in.generateinvoice.model;

import javax.persistence.*;

@Entity
@Table(name="ProjectManager")
public class ProjectManager {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="projectManagerEntryId")
    private int projectManagerEntryId;
    @Column(name="projectManagerLoginId")
    private String projectManagerLoginId;
    @Column(name="projectManagerName")
    private String projectManagerName;
    @Column(name="projectManagerPassword")
    private String projectManagerPassword;

    public int getProjectManagerEntryId() {
        return projectManagerEntryId;
    }

    public void setProjectManagerEntryId(int projectManagerEntryId) {
        this.projectManagerEntryId = projectManagerEntryId;
    }

    public String getProjectManagerLoginId() {
        return projectManagerLoginId;
    }

    public void setProjectManagerLoginId(String projectManagerLoginId) {
        this.projectManagerLoginId = projectManagerLoginId;
    }

    public String getProjectManagerName() {
        return projectManagerName;
    }

    public void setProjectManagerName(String projectManagerName) {
        this.projectManagerName = projectManagerName;
    }

    public String getProjectManagerPassword() {
        return projectManagerPassword;
    }

    public void setProjectManagerPassword(String projectManagerPassword) {
        this.projectManagerPassword = projectManagerPassword;
    }
}
