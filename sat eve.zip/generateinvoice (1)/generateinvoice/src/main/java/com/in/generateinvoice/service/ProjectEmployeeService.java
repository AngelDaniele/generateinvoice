package com.in.generateinvoice.service;

import com.in.generateinvoice.exception.EmployeeNotFoundException;
import com.in.generateinvoice.model.Employee;
import com.in.generateinvoice.model.Project;
import com.in.generateinvoice.model.ProjectEmployeeUI;
import com.in.generateinvoice.model.ProjectEmployees;
import com.in.generateinvoice.repository.EmployeeRepository;
import com.in.generateinvoice.repository.ProjectEmployeeRepository;
import com.in.generateinvoice.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProjectEmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private ProjectEmployeeRepository projectEmployeeRepository;

    public ProjectEmployees saveProjectEmployee(ProjectEmployeeUI projectEmployeeUI) {
        Employee employee = employeeRepository.findByEmployeeId(projectEmployeeUI.getEmployeeId());
        Project project = projectRepository.findByProjectId(projectEmployeeUI.getProjectId());

        ProjectEmployees projectEmployees = new ProjectEmployees();
        projectEmployees.setEmployee(employee);
        projectEmployees.setProject(project);

        projectEmployeeRepository.save(projectEmployees);


        ProjectEmployees response = new ProjectEmployees();
        response.setProjectEmployeeId(projectEmployees.getProjectEmployeeId());
        response.setProject(projectEmployees.getProject());
        response.setEmployee(projectEmployees.getEmployee());

        return response;
    }

    public List<ProjectEmployees> getProjectEmployee(){
        List<ProjectEmployees> list = projectEmployeeRepository.findAll();
        if(list!=null){
            return list;

        }
        throw new EmployeeNotFoundException("Project is not yet assigned");
    }



    public List<ProjectEmployees> getAllProjectEmployeesByProjectId(String projectId) {
        return projectEmployeeRepository.findByProject_ProjectId(projectId);
    }





}
