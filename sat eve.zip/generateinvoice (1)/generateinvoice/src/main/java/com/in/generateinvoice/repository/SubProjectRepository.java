package com.in.generateinvoice.repository;

import com.in.generateinvoice.model.SubProject;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SubProjectRepository extends JpaRepository<SubProject,Integer> {


    List<SubProject> findByProject_ProjectId(String projectId);
    @Query("SELECT s FROM SubProject s JOIN FETCH s.project")
    List<SubProject> findAllWithProjectDetails();


//    List<SubProject> findAllWithProjectDetails();
}
