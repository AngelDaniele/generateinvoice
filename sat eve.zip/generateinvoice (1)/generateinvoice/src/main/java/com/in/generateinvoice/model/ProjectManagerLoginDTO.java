package com.in.generateinvoice.model;

public class ProjectManagerLoginDTO {

    private String projectManagerLoginId;

    private String projectManagerPassword;

    public String getProjectManagerLoginId() {
        return projectManagerLoginId;
    }

    public void setProjectManagerLoginId(String projectManagerLoginId) {
        this.projectManagerLoginId = projectManagerLoginId;
    }

    public String getProjectManagerPassword() {
        return projectManagerPassword;
    }

    public void setProjectManagerPassword(String projectManagerPassword) {
        this.projectManagerPassword = projectManagerPassword;
    }
}
