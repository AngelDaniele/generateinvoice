package com.in.generateinvoice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenerateinvoiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(GenerateinvoiceApplication.class, args);
	}

}
