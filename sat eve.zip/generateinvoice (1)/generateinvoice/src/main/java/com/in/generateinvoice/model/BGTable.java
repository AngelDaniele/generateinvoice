package com.in.generateinvoice.model;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "BGTable")
public class BGTable {






        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "bgTableId")
        private int bgTableId;

        @ManyToOne
        @JoinColumn(name = "billGenerateTableId")
        private BillGenerate billGenerate;

         @ManyToOne
        @JoinColumn(name = "projectEmployeeId")
         private ProjectEmployees projectEmployees;

        @Column(name = "employeeWorkingStartDate")
        private LocalDate employeeWorkingStartDate;

        @Column(name = "employeeWorkingEndDate")
        private LocalDate employeeWorkingEndDate;

        @Column(name = "totalDays")
        private int totalDays;

        @Column(name = "totalAmount")
        private int totalAmount;

        @Column(name = "rate")
        private int rate;

    public int getBgTableId() {
        return bgTableId;
    }

    public void setBgTableId(int bgTableId) {
        this.bgTableId = bgTableId;
    }

    public BillGenerate getBillGenerate() {
        return billGenerate;
    }

    public void setBillGenerate(BillGenerate billGenerate) {
        this.billGenerate = billGenerate;
    }

    public ProjectEmployees getProjectEmployees() {
        return projectEmployees;
    }

    public void setProjectEmployees(ProjectEmployees projectEmployees) {
        this.projectEmployees = projectEmployees;
    }

    public LocalDate getEmployeeWorkingStartDate() {
        return employeeWorkingStartDate;
    }

    public void setEmployeeWorkingStartDate(LocalDate employeeWorkingStartDate) {
        this.employeeWorkingStartDate = employeeWorkingStartDate;
    }

    public LocalDate getEmployeeWorkingEndDate() {
        return employeeWorkingEndDate;
    }

    public void setEmployeeWorkingEndDate(LocalDate employeeWorkingEndDate) {
        this.employeeWorkingEndDate = employeeWorkingEndDate;
    }

    public int getTotalDays() {
        return totalDays;
    }

    public void setTotalDays(int totalDays) {
        this.totalDays = totalDays;
    }

    public int getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(int totalAmount) {
        this.totalAmount = totalAmount;
    }

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }
}


