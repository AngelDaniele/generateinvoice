package com.in.generateinvoice.controller;

import com.in.generateinvoice.model.BGTable;
import com.in.generateinvoice.model.BGTableClient;
import com.in.generateinvoice.service.BGTableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
@RequestMapping("/bgtable")
public class BGTableController {
@Autowired
BGTableService bgTableService;


    @PostMapping("/insertOrUpdate")
    public ResponseEntity<BGTable> insertOrUpdateBGTableEntry(@RequestBody BGTableClient bgTableClient) {
        BGTable savedBGTable = bgTableService.insertOrUpdateBGTableEntry(bgTableClient);
        return new ResponseEntity<>(savedBGTable, HttpStatus.CREATED);
    }
}
