package com.in.generateinvoice.repository;

import com.in.generateinvoice.model.Client;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ClientRepository extends JpaRepository<Client,Integer> {



    Client findByClientId(String clientId);


}
