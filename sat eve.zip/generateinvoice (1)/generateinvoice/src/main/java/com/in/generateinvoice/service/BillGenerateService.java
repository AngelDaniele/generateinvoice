package com.in.generateinvoice.service;

import com.in.generateinvoice.exception.EmployeeNotFoundException;
import com.in.generateinvoice.exception.ProjectNotFoundException;
import com.in.generateinvoice.model.*;
import com.in.generateinvoice.repository.BGTableRepository;
import com.in.generateinvoice.repository.BillGenerateRepository;
import com.in.generateinvoice.repository.ProjectEmployeeRepository;
import com.in.generateinvoice.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class BillGenerateService {



        @Autowired
        private ProjectRepository projectRepository;

        @Autowired
        private ProjectEmployeeRepository projectEmployeeRepository;

        @Autowired
        private BillGenerateRepository billGenerateRepository;
    @Autowired
    ProjectEmployeeService   projectEmployeeService;



        @Autowired
        private BGTableRepository bgTableRepository; // You need a repository for BGTable



    public BillGenerate saveBillGenerateUI(BillGenerateUI billGenerateUI) {
        // Retrieve the Project object based on your application's logic
        Project project = projectRepository.findByProjectId(billGenerateUI.getProjectId());

        if (project != null) {
            // Check if billGenerateStartDate is within the project's startDate and endDate
            LocalDate billGenerateStartDate = billGenerateUI.getBillGenerateStartDate();
            LocalDate projectStartDate = project.getStartDate();
            LocalDate projectEndDate = project.getEndDate();

            if (billGenerateStartDate.isAfter(projectStartDate) && billGenerateStartDate.isBefore(projectEndDate)) {
                // Check if billGenerateEndDate is within the project's startDate and endDate
                LocalDate billGenerateEndDate = billGenerateUI.getBillGenerateEndDate();

                if (billGenerateEndDate.isAfter(projectStartDate) && billGenerateEndDate.isBefore(projectEndDate)) {
                    // Retrieve the ProjectEmployees associated with the Project
                    List<ProjectEmployees> projectEmployeesList = projectEmployeeService.getAllProjectEmployeesByProjectId(project.getProjectId());

                    if (!projectEmployeesList.isEmpty()) {
                        // Map BillGenerateUI to BillGenerate
                        BillGenerate billGenerate = new BillGenerate();

                        // Set the project using the provided object
                        billGenerate.setProject(project);

                        // Set the other properties from BillGenerateUI
                        billGenerate.setBillGenerateStartDate(billGenerateStartDate);
                        billGenerate.setBillGenerateEndDate(billGenerateEndDate);

                        // You can set other properties here if needed

                        // Save the BillGenerate object to the database
                        billGenerate = billGenerateRepository.save(billGenerate);

                        // For each project employee, create an entry in the BGTable
                        for (ProjectEmployees projectEmployee : projectEmployeesList) {
                            BGTable bgTable = new BGTable();
                            bgTable.setBillGenerate(billGenerate);
                            bgTable.setProjectEmployees(projectEmployee);
//                            bgTable.setEmployeeWorkingStartDate(billGenerateStartDate);
//                            bgTable.setEmployeeWorkingEndDate(billGenerateEndDate);

                            // Calculate totalDays, totalAmount, and rate as needed
                            // For simplicity, you can set them to 0 initially and update them later

                            // Save the BGTable entry
                            bgTableRepository.save(bgTable);
                        }

                        return billGenerate;
                    } else {
                        throw new EmployeeNotFoundException("Project is not yet assigned");
                    }
                } else {
                    throw new IllegalArgumentException("billGenerateEndDate is not within project startDate and endDate");
                }
            } else {
                throw new IllegalArgumentException("billGenerateStartDate is not within project startDate and endDate");
            }
        } else {
            // Handle the case where the project was not found
            throw new ProjectNotFoundException("Project not found");
        }
    }}





//
//    public BillGenerate saveBillGenerateUI(BillGenerateUI billGenerateUI) {
//        // Retrieve the Project object based on your application's logic
//        Project project = projectRepository.findByProjectId(billGenerateUI.getProjectId());
//
//        if (project != null) {
//            // Check if billGenerateStartDate is within the project's startDate and endDate
//            LocalDate billGenerateStartDate = billGenerateUI.getBillGenerateStartDate();
//            LocalDate projectStartDate = project.getStartDate();
//            LocalDate projectEndDate = project.getEndDate();
//
//            if (billGenerateStartDate.isAfter(projectStartDate) && billGenerateStartDate.isBefore(projectEndDate)) {
//                // Check if billGenerateEndDate is within the project's startDate and endDate
//                LocalDate billGenerateEndDate = billGenerateUI.getBillGenerateEndDate();
//
//                if (billGenerateEndDate.isAfter(projectStartDate) && billGenerateEndDate.isBefore(projectEndDate)) {
//                    // Retrieve the ProjectEmployees associated with the Project
//                    List<ProjectEmployees> projectEmployeesList = projectEmployeeService.getAllProjectEmployeesByProjectId(project.getProjectId());
//
//                    if (!projectEmployeesList.isEmpty()) {
//                        // For simplicity, assuming you want to use the first project employee found
//                        ProjectEmployees projectEmployees = projectEmployeesList.get(0);
//
//                        // Map BillGenerateUI to BillGenerate
//                        BillGenerate billGenerate = new BillGenerate();
//
//                        // Set the project and projectEmployees using the provided objects
//                        billGenerate.setProject(project);
//                        billGenerate.setProjectEmployees(projectEmployees);
//
//                        // Set the other properties from BillGenerateUI
//                        billGenerate.setBillGenerateStartDate(billGenerateStartDate);
//                        billGenerate.setBillGenerateEndDate(billGenerateEndDate);
//
//                        // You can set other properties here if needed
//
//                        // Save the BillGenerate object to the database
//                        return billGenerateRepository.save(billGenerate);
//                    } else {
//                        throw new EmployeeNotFoundException("Project is not yet assigned");
//                    }
//                } else {
//                    throw new IllegalArgumentException("billGenerateEndDate is not within project startDate and endDate");
//                }
//            } else {
//                throw new IllegalArgumentException("billGenerateStartDate is not within project startDate and endDate");
//            }
//        } else {
//            // Handle the case where the project was not found
//            throw new ProjectNotFoundException("Project not found");
//        }
//    }



























