package com.in.generateinvoice.controller;

import com.in.generateinvoice.exception.EmployeeNotFoundException;
import com.in.generateinvoice.exception.ProjectNotFoundException;
import com.in.generateinvoice.model.BillGenerate;
import com.in.generateinvoice.model.BillGenerateUI;
import com.in.generateinvoice.service.BillGenerateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api/billgenerate")
public class BillGenerateController {


    @Autowired
    private BillGenerateService billGenerateService;

    @PostMapping("/create")
    public ResponseEntity<BillGenerate> createBillGenerate(@RequestBody BillGenerateUI billGenerateUI) {
        try {
            BillGenerate savedBillGenerate = billGenerateService.saveBillGenerateUI(billGenerateUI);
            return ResponseEntity.ok(savedBillGenerate);
        } catch (EmployeeNotFoundException e) {
            return ResponseEntity.badRequest().body(null); // You can return null or an empty body if needed
        } catch (ProjectNotFoundException e) {
            return ResponseEntity.badRequest().body(null); // You can return null or an empty body if needed
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null); // You can return null or an empty body if needed
        }
    }
}




