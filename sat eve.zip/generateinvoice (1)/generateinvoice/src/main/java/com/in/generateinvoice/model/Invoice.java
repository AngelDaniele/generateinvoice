//package com.in.generateinvoice.model;
//
//import javax.persistence.Entity;
//import javax.persistence.Table;
//
//@Entity
//@Table(name="Invoice")
//public class Invoice {
//
//    private int invoiceNo;
//
//
//
//
//
//
//}
