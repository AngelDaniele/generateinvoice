package com.in.generateinvoice.model;

import java.time.LocalDate;

public class BillGenerateUI {


    private String projectId;



    private LocalDate billGenerateStartDate;

    private LocalDate billGenerateEndDate;

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }



    public LocalDate getBillGenerateStartDate() {
        return billGenerateStartDate;
    }

    public void setBillGenerateStartDate(LocalDate billGenerateStartDate) {
        this.billGenerateStartDate = billGenerateStartDate;
    }

    public LocalDate getBillGenerateEndDate() {
        return billGenerateEndDate;
    }

    public void setBillGenerateEndDate(LocalDate billGenerateEndDate) {
        this.billGenerateEndDate = billGenerateEndDate;
    }
}
