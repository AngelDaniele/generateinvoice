package com.in.generateinvoice.service;

import com.in.generateinvoice.model.BGTable;
import com.in.generateinvoice.model.BGTableClient;
import com.in.generateinvoice.model.BillGenerate;
import com.in.generateinvoice.repository.BGTableRepository;
import com.in.generateinvoice.repository.BillGenerateRepository;
import com.in.generateinvoice.repository.ProjectEmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class BGTableService {


        @Autowired
        private BGTableRepository bgTableRepository;

        @Autowired
        private BillGenerateRepository billGenerateRepository;

        @Autowired
        private ProjectEmployeeRepository projectEmployeeRepository;
    public BGTable insertOrUpdateBGTableEntry(BGTableClient bgTableClient) {
        // Check if a BGTable entry with the same bgTableId already exists
        Optional<BGTable> existingBGTableOptional = bgTableRepository.findById(bgTableClient.getBgTableId());

        if (existingBGTableOptional.isPresent()) {
            // Update the existing BGTable entry
            BGTable existingBGTable = existingBGTableOptional.get();

            // Set the fields from BGTableClient for update
            existingBGTable.setEmployeeWorkingStartDate(bgTableClient.getEmployeeWorkingStartDate());
            existingBGTable.setEmployeeWorkingEndDate(bgTableClient.getEmployeeWorkingEndDate());
            existingBGTable.setTotalDays(bgTableClient.getTotalDays());
            existingBGTable.setRate(bgTableClient.getRate());
            existingBGTable.setTotalAmount(bgTableClient.getTotalAmount());

            // Save the updated BGTable entry
            return bgTableRepository.save(existingBGTable);
        } else {
            // Create a new BGTable entry since it doesn't exist
            BGTable bgTable = new BGTable();

            // Set the fields from BGTableClient for insertion
            bgTable.setEmployeeWorkingStartDate(bgTableClient.getEmployeeWorkingStartDate());
            bgTable.setEmployeeWorkingEndDate(bgTableClient.getEmployeeWorkingEndDate());
            bgTable.setTotalDays(bgTableClient.getTotalDays());
            bgTable.setRate(bgTableClient.getRate());
            bgTable.setTotalAmount(bgTableClient.getTotalAmount());

            // Retrieve the corresponding BillGenerate entity
            BillGenerate billGenerate = getBillGenerate(bgTableClient.getBgTableId());
            if (billGenerate == null) {
                throw new IllegalArgumentException("Invalid billGenerateTableId");
            }

            // Set the BillGenerate entity in BGTable
            bgTable.setBillGenerate(billGenerate);

            // Save the new BGTable entry to the database
            return bgTableRepository.save(bgTable);
        }
    }




    private BillGenerate getBillGenerate(int billGenerateTableId) {
        // Implement logic to retrieve BillGenerate entity from the database based on billGenerateTableId
        Optional<BillGenerate> optionalBillGenerate = billGenerateRepository.findById(billGenerateTableId);

        if (optionalBillGenerate.isPresent()) {
            return optionalBillGenerate.get();
        } else {
            return null; // or throw an exception if needed
        }
    }

        }


