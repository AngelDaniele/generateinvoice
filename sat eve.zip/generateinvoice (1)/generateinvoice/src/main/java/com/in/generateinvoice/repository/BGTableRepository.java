package com.in.generateinvoice.repository;

import com.in.generateinvoice.model.BGTable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface BGTableRepository extends JpaRepository<BGTable,Integer> {
    Optional<BGTable> findByBillGenerate_BillGenerateTableId(int billGenerateTableId);
}
