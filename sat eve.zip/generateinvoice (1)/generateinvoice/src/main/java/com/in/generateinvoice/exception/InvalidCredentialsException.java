package com.in.generateinvoice.exception;

public class InvalidCredentialsException extends RuntimeException{



     public InvalidCredentialsException(String message){

         super(message);


     }

}
