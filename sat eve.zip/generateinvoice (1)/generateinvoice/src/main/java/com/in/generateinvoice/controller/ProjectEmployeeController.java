package com.in.generateinvoice.controller;

import com.in.generateinvoice.model.ProjectEmployeeUI;
import com.in.generateinvoice.model.ProjectEmployees;
import com.in.generateinvoice.service.ProjectEmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/projectEmployee")
public class ProjectEmployeeController {

    @Autowired
    ProjectEmployeeService projectEmployeeService;


    @PostMapping("/save")
    public ResponseEntity<ProjectEmployees> saveProjectEmployee(@RequestBody ProjectEmployeeUI projectEmployeeUI) {
        ProjectEmployees response = projectEmployeeService.saveProjectEmployee(projectEmployeeUI);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getProjectEmployee")
    public List<ProjectEmployees> getAllProjectEmployee(){
        return projectEmployeeService.getProjectEmployee();
    }


}
