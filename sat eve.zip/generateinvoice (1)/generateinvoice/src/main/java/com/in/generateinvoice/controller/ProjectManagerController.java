package com.in.generateinvoice.controller;

import com.in.generateinvoice.model.ProjectManager;
import com.in.generateinvoice.model.ProjectManagerLoginDTO;
import com.in.generateinvoice.service.ProjectManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/ProjectManager")
public class ProjectManagerController {

@Autowired
    ProjectManagerService projectManagerService;

   @PostMapping("/saveProjectManager")
   public ResponseEntity<ProjectManager> saveAdmin(@RequestBody ProjectManager projectManager) {
       ProjectManager responseAdmin = projectManagerService.saveProjectManager(projectManager);
       return new ResponseEntity<ProjectManager>(responseAdmin, HttpStatus.CREATED);
   }

    @PostMapping("/login")
    public ResponseEntity<ProjectManager> loginProjectManager(@RequestBody ProjectManagerLoginDTO loginDTO) {
        {
            ProjectManager msg= projectManagerService.loginProjectManager(loginDTO);
            return new ResponseEntity<ProjectManager>(msg,HttpStatus.ACCEPTED);
        }
   }










}
